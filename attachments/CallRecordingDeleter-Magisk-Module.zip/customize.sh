#!/system/bin/sh

MODDIR=${0%/*}

# Set permissions
chmod 0755 $MODDIR/system/bin/callrec_deleter

# Create service script
mkdir -p /data/adb/service.d

cat > /data/adb/service.d/callrec_deleter.sh << 'EOF'
#!/system/bin/sh

# Wait for boot
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done

# Wait for storage
until [ -d "/storage/emulated/0/Music/Call Recordings" ]; do
    sleep 5
done

# Start deleter with root permissions
nohup /system/bin/callrec_deleter > /dev/null 2>&1 &
EOF

chmod 0755 /data/adb/service.d/callrec_deleter.sh